const express = require('express');
const bodyParser = require('body-parser');
const MongoClient = require('mongodb').MongoClient;
const app = express();
const url = "mongodb://localhost:27017/";
MongoClient.connect(url, { useUnifiedTopology: true })
  .then(client => {
    console.log('Connected to Database');
    const db = client.db('goodhealthDb');
    const patientCollection = db.collection('patient');
    const paymentCollection = db.collection('payment');
    const studentCollection = db.collection('student');

    app.set('view engine', 'ejs');
    app.use(bodyParser.urlencoded({ extended: true }));
    app.use(bodyParser.json());
    app.use(express.static('public'));


    app.get('/', function (req, res) {
        res.render('index.ejs');
    });

    app.post('/', function (req, res) {
        if(req.body.inputEmail == "admin" && req.body.inputPassword == "admin")
        res.render('patientList.ejs');
    });
    app.get('/patientList', function (req, res) {
        db.collection('patient').find().toArray()
        .then(patients => {
          res.render('patientList.ejs', { patients: patients })
        })
        .catch(error => console.error(error))
        
    });
    app.get('/paymentList', function (req, res) {
        db.collection('payment').find().toArray()
        .then(payments => {
          res.render('paymentList.ejs', { payments: payments })
        })
        .catch(error => console.error(error))
    });

    app.get('/addPatient', function (req, res) {
        res.render('addPatient.ejs');
    });

    app.post('/addPatient', function (req, res) {
        var myobj = { fullname: req.params.fullNameInput, 
            dob: req.body.dobInput, 
            phone: req.body.contactInput, 
            residence:req.body.residentialInput, 
            emergency:req.body.emergencyInput
        };
        patientCollection.insertOne(myobj)
        .then(result => {
            console.log("1 document inserted");
            res.redirect('/patientList')
        })
        .catch(error => console.error(error));
    });
    app.put('/editPatient', (req, res) => {
        patientCollection.findOneAndUpdate(
          {  _id: req.body.ID },
          {
            $set: {
                dob: req.body.dobInput, 
                phone: req.body.contactInput, 
                residence:req.body.residentialInput, 
                emergency:req.body.emergencyInput
            }
          },
          {
            upsert: true
          }
        )
          .then(result => res.json('Success'))
          .catch(error => console.error(error))
      })
  
      app.delete('/deletePatient', (req, res) => {
        patientCollection.deleteOne(
          { _id: req.body.ID }
        )
          .then(result => {
            if (result.deletedCount === 0) {
              return res.json('No patient to delete')
            }
            res.json('Deleted '+ result.deletedCount + ' records')
          })
          .catch(error => console.error(error))
      })
    app.get('/addPayment', function (req, res) {
        res.render('addPayment.ejs');
    });

    app.post('/addPayment', function (req, res) {
        var myobj = { fullname: req.params.fullNameInput, 
            datepaid: req.body.datePaid, 
            amountpaid: req.body.amtPaid, 
            balance:req.body.balanceInput
            };
        paymentCollection.insertOne(myobj)
        .then(result => {
            console.log("1 document inserted");
            res.redirect('/patientList')
        })
        .catch(error => console.error(error));
    });

    app.put('/editPayment', (req, res) => {
        paymentCollection.findOneAndUpdate(
          {  _id: req.body.ID },
          {
            $set: {
                fullname: req.params.fullNameInput, 
                datepaid: req.body.datePaid, 
                amountpaid: req.body.amtPaid, 
                balance:req.body.balanceInput
            }
          },
          {
            upsert: true
          }
        )
          .then(result => res.json('Success'))
          .catch(error => console.error(error))
      })
  
      app.delete('/deletePayment', (req, res) => {
        paymentCollection.deleteOne(
          { _id: req.body.ID }
        )
          .then(result => {
            if (result.deletedCount === 0) {
              return res.json('No payment to delete')
            }
            res.json('Deleted '+ result.deletedCount + ' records')
          })
          .catch(error => console.error(error))
      })
    // ====== student question
    app.get('/student', (req, res) => {
        db.collection('student').find().toArray()
          .then(students => {
            res.render('studentList.ejs', { students: students })
          })
          .catch(error => console.error(error))
      })
  
      app.post('/student', (req, res) => {
        studentCollection.insertOne(req.body)
          .then(result => {
            res.redirect('/')
          })
          .catch(error => console.error(error))
      })
  
      app.put('/student', (req, res) => {
        studentCollection.findOneAndUpdate(
          {  _id: req.body.ID },
          {
            $set: {
              firstname: req.body.firstname,
              lastname: req.body.lastname,
              dob : req.body.dob,
              phone : req.body.phone
            }
          },
          {
            upsert: true
          }
        )
          .then(result => res.json('Success'))
          .catch(error => console.error(error))
      })
  
      app.delete('/student', (req, res) => {
        studentCollection.deleteOne(
          { _id: req.body.ID }
        )
          .then(result => {
            if (result.deletedCount === 0) {
              return res.json('No student to delete')
            }
            res.json('Deleted '+ result.deletedCount + ' records')
          })
          .catch(error => console.error(error))
      })
  

    //======= mssql todo question

    app.get('/todo/get', (req, res) => {
        const sql = require("mssql");
        // config db
        const config = {
            user: 'DB_A2A9C5_db_admin',
            password: 'pass@word123',
            server: 'sql6009.site4now.net', 
            database: 'DB_A2A9C5_db' 
        };
    
        // connect to your database
        sql.connect(config, function (err) {        
            if (err) console.log(err);    
            // create Request object
            var request = new sql.Request();
            // query to the database and get the records
            request.query('select * from TblTodoRecord', function (err, recordset) {                
                if (err) console.log(err)    
                // send records as a response
                res.send(recordset);                
            });
        });
      })
  
      app.post('/todo/post', (req, res) => {
        const sql = require("mssql");
        // config db
        const config = {
            user: 'DB_A2A9C5_db_admin',
            password: 'pass@word123',
            server: 'sql6009.site4now.net', 
            database: 'DB_A2A9C5_db' 
        };
    
        // connect to your database
        sql.connect(config, function (err) {        
            if (err) console.log(err);    
            // create Request object
            var request = new sql.Request();
            // insert into db and get the count
            request.query('insert into TblTodoRecord (Title, Description) VALUES ('+req.body.title+', '+req.body.desc+')', function (err, recordset) {                
                if (err) console.log(err)    
                // send records as a response
                res.send(recordset);                
            });
        });
      })
  
    
      app.delete('/todo/delete', (req, res) => {
        const sql = require("mssql");
        // config db
        const config = {
            user: 'DB_A2A9C5_db_admin',
            password: 'pass@word123',
            server: 'sql6009.site4now.net', 
            database: 'DB_A2A9C5_db' 
        };
    
        // connect to your database
        sql.connect(config, function (err) {        
            if (err) console.log(err);    
            // create Request object
            var request = new sql.Request();
            // delete the records
            request.query('DELETE FROM TblTodoRecord WHERE id = '+req.body.id, function (err, recordset) {                
                if (err) console.log(err)    
                res.send(recordset);                
            });
        });
      })


      //=========== listen on server 3000

    app.listen(3000, function () {
    console.log('listening on port 3000')
    });
  });