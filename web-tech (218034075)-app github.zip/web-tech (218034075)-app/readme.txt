to export database use
mongodump --host=localhost --port=27017 --db goodhealthDb --out=./dbexport/

to import database use
mongorestore dbexport/

make sure your mongodb bin classpath has been specified

use admin as email and admin as password to login

